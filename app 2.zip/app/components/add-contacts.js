// add the contacts class component here

