// redo this as a functional component
import React from 'react';


export default (props) =>{

   
        return (
            <section>
                <div className="push"></div>
                <div id="pulse-footer">
                    <p>© Pulse / All Rights Reserved.</p>
                </div>
            </section>
        );
}
